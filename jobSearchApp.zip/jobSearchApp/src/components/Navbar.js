import React from 'react';
import './Navbar.css';

function Navbar() {
    return (
        <nav className="navbar">
            <div className="navbar-left">
                <h1 className="logo">arbeitSearch</h1>
            </div>
            <div className="navbar-right">
                <a href="#blog">Blogs</a>
                <a href="#podcast">Podcasts</a>
                <div className="dropdown">
                    <button className="dropbtn">Find Us ▾</button>
                    <div className="dropdown-content">
                        <a href="https://facebook.com" target="_blank" rel="noreferrer">Facebook</a>
                        <a href="https://twitter.com" target="_blank" rel="noreferrer">Twitter</a>
                        <a href="https://instagram.com" target="_blank" rel="noreferrer">Instagram</a>
                        <a href="https://linkedin.com" target="_blank" rel="noreferrer">LinkedIn</a>
                    </div>
                </div>
                <button className="btn">Sign In</button>
                <button className="btn primary">Post a Job</button>
            </div>
        </nav>
    );
}

export default Navbar;
