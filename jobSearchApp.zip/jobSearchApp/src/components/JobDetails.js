import React from 'react';
import './JobDetails.css';

function JobDetails({ job, onBack }) {
    return (
        <div className="job-details-view">
            <button className="back-btn" onClick={onBack}>← Back to Listings</button>
            <h2>{job.position}</h2>
            <h4>{job.company}</h4>
            <p><strong>Location:</strong> {job.location}</p>
            {job.tags 
            // && (
            //     <div className="tags">
            //         {job.tags.map((tag, i) => (
            //             <span key={i} className="tag">{tag}</span>
            //         )
            //         )}
            //     </div>)
                }
            <div
                className="job-description"
                dangerouslySetInnerHTML={{ __html: job.description }}
            />
            <a
                href={job.url}
                target="_blank"
                rel="noopener noreferrer"
                className="apply-button"
            >
                Apply Now
            </a>
        </div>
    );
}

export default JobDetails;
