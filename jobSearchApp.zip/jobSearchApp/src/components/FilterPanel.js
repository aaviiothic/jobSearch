import React from 'react';
import './FilterPanel.css';

function FilterPanel({ filters, onFilterChange, onClear }) {
    const handleChange = (e) => {
        const { name, value } = e.target;
        onFilterChange(name, value);
    };

    return (
        <div className="filter-panel">
            <h3>
                Search remote jobs{' '}
                <span className="clear" onClick={onClear}>Clear</span>
            </h3>
            <input
                name="search"
                value={filters.search}
                onChange={handleChange}
                type="text"
                placeholder="Search company..."
            />
            <label>Job Categories</label>
            <input
                name="category"
                value={filters.category}
                onChange={handleChange}
                type="text"
                placeholder="Search job category..."
            />
            <label>Countries</label>
            <input
                name="country"
                value={filters.country}
                onChange={handleChange}
                type="text"
                placeholder="Search country..."
            />
            <label>Salary Range</label>
            <div className="salary-range-inputs">
                <input
                    name="minSalary"
                    value={filters.minSalary}
                    onChange={handleChange}
                    type="number"
                    placeholder="Min salary"
                />
                <input
                    name="maxSalary"
                    value={filters.maxSalary}
                    onChange={handleChange}
                    type="number"
                    placeholder="Max salary"
                />
            </div>
            <label>Skills</label>
            <input
                name="skills"
                value={filters.skills}
                onChange={handleChange}
                type="text"
                placeholder="Search skills..."
            />
            <button className="apply-btn" onClick={() => {}}>Apply filters</button>
        </div>
    );
}

export default FilterPanel;
