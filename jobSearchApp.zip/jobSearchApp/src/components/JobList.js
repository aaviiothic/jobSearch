import React, { useState } from 'react';
import JobCard from './JobCard';
import './JobList.css';

function JobList({ jobs, onViewJob }) {
    const [currentPage, setCurrentPage] = useState(1);
    const jobsPerPage = 5;

    const indexOfLastJob = currentPage * jobsPerPage;
    const indexOfFirstJob = indexOfLastJob - jobsPerPage;
    const currentJobs = jobs.slice(indexOfFirstJob, indexOfLastJob);
    const totalPages = Math.ceil(jobs.length / jobsPerPage);

    const paginate = (pageNumber) => {
        setCurrentPage(pageNumber);
    };

    const renderPageNumbers = () => {
        const pageNumbers = [];
        let startPage = Math.max(1, currentPage - 1);
        let endPage = Math.min(totalPages, startPage + 2);

        if (endPage - startPage < 2) {
            startPage = Math.max(1, endPage - 2);
        }

        for (let i = startPage; i <= endPage; i++) {
            pageNumbers.push(
                <button
                    key={i}
                    className={`page-btn ${i === currentPage ? 'active' : ''}`}
                    onClick={() => paginate(i)}
                >
                    {i}
                </button>
            );
        }
        return pageNumbers;
    };

    if (!jobs.length) return <div>No jobs found.</div>;

    return (
        <div>
            <h2>Latest Remote Jobs</h2>
            {currentJobs.map((job) => (
                <JobCard key={job.id} job={job} onViewJob={() => onViewJob(job)} />
            ))}
            <div className="pagination-container">
                <button
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                    className="nav-btn"
                    disabled={currentPage === 1}
                >
                    ← Prev
                </button>
                <div className="page-buttons">{renderPageNumbers()}</div>
                <button
                    onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                    className="nav-btn"
                    disabled={currentPage === totalPages}
                >
                    Next →
                </button>
            </div>
        </div>
    );
}

export default JobList;
