import React from 'react';
import './JobCard.css';
import defaultlogo from '../assets/orgLogoDefault.png';


function JobCard({ job, onViewJob }) {

    const handleImageError = (e) => {
        e.target.src = defaultlogo;
    };
    
    return (
        <div className="job-card">
            <div className="logo-container">
                {job.company_logo && (
                    <img
                        src={job.companyLogo || defaultlogo}
                        alt={`${job.company} logo`}
                        className="company-logo"
                        onError={handleImageError}
                    />
                )}
            </div>
            <div className="job-details">
                <h3>{job.position}</h3>
                <h4 className="company-name">{job.company}</h4>
                <p className="location">{job.location}</p>
                {job.tags && job.tags.length > 0
                // && (
                    // <div className="tags">
                    //     {job.tags.map((tag, index) => (
                    //         <span key={index} className="tag">{tag}</span>
                    //     ))}
                    // </div>)
                    }
                <p className="posted-date">
                    Posted: {new Date(job.date).toLocaleDateString()}
                </p>
                <button className="view-button" onClick={onViewJob}>
                    View Job
                </button>
            </div>
        </div>
    );
}

export default JobCard;
