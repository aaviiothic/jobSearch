import React, { useState, useEffect } from 'react';
import JobList from './components/JobList';
import FilterPanel from './components/FilterPanel';
import JobDetails from './components/JobDetails';
import './App.css';
import Navbar from './components/Navbar';

function App() {
    const [jobs, setJobs] = useState([]);
    const [filteredJobs, setFilteredJobs] = useState([]);
    const [filters, setFilters] = useState({
        search: '',
        category: '',
        country: '',
        salary: '',
        skills: ''
    });
    const [selectedJob, setSelectedJob] = useState(null);

    useEffect(() => {
        fetch('/api/jobs') 

            .then(res => res.json())
            .then(data => {
                const actualJobs = data.slice(1);
                setJobs(actualJobs);
                setFilteredJobs(actualJobs);
            });
    }, []);

    useEffect(() => {
        let result = [...jobs];
        if (filters.search) {
            const q = filters.search.toLowerCase();
            result = result.filter(job =>
                job.position?.toLowerCase().includes(q) ||
                job.company?.toLowerCase().includes(q)
            );
        }

        if (filters.category) {
            result = result.filter(job =>
                job.tags?.some(tag => tag.toLowerCase().includes(filters.category.toLowerCase()))
            );
        }

        if (filters.country) {
            result = result.filter(job =>
                job.location?.toLowerCase().includes(filters.country.toLowerCase())
            );
        }

        if (filters.skills) {
            result = result.filter(job =>
                job.tags?.some(tag => tag.toLowerCase().includes(filters.skills.toLowerCase()))
            );
        }

        setFilteredJobs(result);
    }, [filters, jobs]);

    const handleFilterChange = (name, value) => {
        setFilters(prev => ({ ...prev, [name]: value }));
    };

    const clearFilters = () => {
        setFilters({ search: '', category: '', country: '', salary: '', skills: '' });
    };

    return (
        <div className="App">
        <Navbar />
            <main className="main-container">
                <div className="left-column">
                    {selectedJob ? (
                        <JobDetails job={selectedJob} onBack={() => setSelectedJob(null)} />
                    ) : (
                        <JobList jobs={filteredJobs} onViewJob={setSelectedJob} />
                    )}
                </div>
                <div className="right-column">
                    <FilterPanel
                        filters={filters}
                        onFilterChange={handleFilterChange}
                        onClear={clearFilters}
                    />
                </div>
            </main>
        </div>
    );
}

export default App;