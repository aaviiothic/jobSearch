using System;
using System.Text.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace jobSearchAPI.Models
{
    public class Job
    {
        public int Id { get; set; }
        public string? JobId { get; set; }
        public string? Slug { get; set; }
        public long Epoch { get; set; }
        public DateTime Date { get; set; }
        public string? Company { get; set; }
        public string? CompanyLogo { get; set; }
        public string? Position { get; set; }

        // Store as string in database, convert to List<string> in application
        [Column("Tags")]
        public string? TagsJson { get; set; }

        [NotMapped]
        public List<string> Tags
        {
            get
            {
                if (string.IsNullOrWhiteSpace(TagsJson))
                    return new List<string>();

                try
                {
                    // Try to parse as JSON array first
                    if (TagsJson.TrimStart().StartsWith("["))
                    {
                        return JsonSerializer.Deserialize<List<string>>(TagsJson) ?? new List<string>();
                    }
                    else
                    {
                        // Handle comma-separated string
                        return TagsJson.Split(',', StringSplitOptions.RemoveEmptyEntries)
                                     .Select(tag => tag.Trim())
                                     .Where(tag => !string.IsNullOrEmpty(tag))
                                     .ToList();
                    }
                }
                catch (JsonException)
                {
                    // Fallback to comma-separated parsing
                    return TagsJson.Split(',', StringSplitOptions.RemoveEmptyEntries)
                                 .Select(tag => tag.Trim())
                                 .Where(tag => !string.IsNullOrEmpty(tag))
                                 .ToList();
                }
            }
            set
            {
                TagsJson = JsonSerializer.Serialize(value);
            }
        }

        public string? Description { get; set; }
        public string? Location { get; set; }
        public int? SalaryMin { get; set; }
        public int? SalaryMax { get; set; }
        public string? ApplyUrl { get; set; }
        public string? Url { get; set; }
        public DateTime? PostedDate { get; set; }
    }
}