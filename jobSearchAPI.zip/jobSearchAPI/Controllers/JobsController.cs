using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using jobSearchAPI.Data;
using jobSearchAPI.Models;
using Microsoft.EntityFrameworkCore;





[Route("api/[controller]")]
[ApiController]
public class JobsController : ControllerBase
{
    private readonly AppDbContext _context;

    public JobsController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Job>>> GetJobs()
    {
        var response = await _context.Jobs.ToListAsync();
        return response;
    }

    [HttpGet("import")]
    public async Task<ActionResult> ImportFromRemoteOk()
    {
        using var client = new HttpClient();
        var response = await client.GetStringAsync("https://remoteok.com/api");

        var json = JsonDocument.Parse(response);
        var jobsJson = json.RootElement.EnumerateArray().Skip(1); // skip metadata

        foreach (var jobJson in jobsJson)
        {
            var job = new Job
            {
                JobId = jobJson.TryGetProperty("id", out var idProp) ? idProp.GetRawText() : Guid.NewGuid().ToString(),
                Slug = jobJson.TryGetProperty("slug", out var slugProp) ? slugProp.GetString() : null,
                Epoch = jobJson.TryGetProperty("epoch", out var epochProp) ? epochProp.GetInt64() : 0,
                Date = jobJson.TryGetProperty("date", out var dateProp) && DateTime.TryParse(dateProp.GetString(), out var parsedDate) ? parsedDate : DateTime.UtcNow,
                Company = jobJson.TryGetProperty("company", out var companyProp) ? companyProp.GetString() : null,
                CompanyLogo = jobJson.TryGetProperty("company_logo", out var logoProp) ? logoProp.GetString() : null,
                Position = jobJson.TryGetProperty("position", out var posProp) ? posProp.GetString() : null,
                Tags = jobJson.TryGetProperty("tags", out var tagsProp)
                    ? tagsProp.EnumerateArray().Select(t => t.GetString()).Where(t => t != null).ToList()
                    : new List<string>(),
                Description = jobJson.TryGetProperty("description", out var descProp) ? descProp.GetString() : null,
                Location = jobJson.TryGetProperty("location", out var locProp) ? locProp.GetString() : "Remote",
                SalaryMin = jobJson.TryGetProperty("salary_min", out var salaryMinProp) ? salaryMinProp.GetInt32() : null,
                SalaryMax = jobJson.TryGetProperty("salary_max", out var salaryMaxProp) ? salaryMaxProp.GetInt32() : null,
                ApplyUrl = jobJson.TryGetProperty("apply_url", out var applyProp) ? applyProp.GetString() : null,
                Url = jobJson.TryGetProperty("url", out var urlProp) ? urlProp.GetString() : null,
                PostedDate = DateTime.UtcNow
            };

            _context.Jobs.Add(job);
        }

        await _context.SaveChangesAsync();
        return Ok(new { message = "Jobs imported." });
    }

}